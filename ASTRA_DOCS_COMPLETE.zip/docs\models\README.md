# GPT-OSS Models Quick Reference

## What Was Integrated

The complete GPT-OSS Model Card (33 pages) has been integrated into ASTRA as structured system intelligence. This includes:

### 1. **Complete Model Documentation** (`docs/models/gpt_oss_model_card.md`)
   - Full specifications for both models (120b and 20b)
   - Architecture details (MoE, attention, quantization)
   - Performance benchmarks across 15+ evaluations
   - Safety and alignment information
   - Deployment guidance

### 2. **Structured Data Models** (`src/astra/models/model_info.py`)
   - Pydantic models for type-safe access:
     - `ModelInfo` - Complete model metadata
     - `ModelArchitecture` - Architecture specifications
     - `PerformanceBenchmark` - Benchmark results
     - `ReasoningModeSpec` - Reasoning mode details
     - `HarmonyFormatSpec` - Chat format specifications
     - `ToolCapability` - Tool use capabilities
     - `SafetySpec` - Safety information
   - Pre-configured `GPT_OSS_120B_INFO` and `GPT_OSS_20B_INFO` objects
   - Registry for easy model lookup

### 3. **Enhanced Configuration** (`src/astra/models/config.py`)
   - Updated `LLMConfig` with GPT-OSS-specific fields:
     - `model_size`: gpt-oss-120b or gpt-oss-20b
     - `reasoning_mode`: low, medium, or high
     - `use_harmony_format`: Enable harmony chat format
     - `enable_browsing`: Web search tool
     - `enable_python`: Jupyter execution tool
     - `enable_developer_functions`: Custom functions
     - `strip_cot_in_history`: Remove CoT from history
     - `context_length`: 131,072 tokens
     - `active_parameters`: Model size info
     - `tokenizer_name`: o200k_harmony

### 4. **Configuration Files**
   - **`config/default.yaml`**: Complete model specifications including:
     - Architecture details for both models
     - Performance benchmarks
     - Reasoning mode specifications
     - Harmony format documentation
     - Tool capabilities
     - Safety guidelines
     - Hardware requirements
   
   - **`.env.example`**: Environment variables for:
     - Model selection
     - Reasoning mode
     - Tool enablement
     - Context length
     - All GPT-OSS features

### 5. **Harmony Format Utilities** (`src/astra/infrastructure/llm/harmony.py`)
   - `HarmonyPromptBuilder` - Construct harmony-formatted prompts
   - `HarmonyMessage` - Structured message representation
   - Role hierarchy: System > Developer > User > Assistant > Tool
   - Channel support: analysis, commentary, final
   - Utility functions:
     - `strip_cot_from_history()` - Remove CoT from conversation history
     - `parse_harmony_response()` - Parse harmony responses
     - `extract_final_response()` - Get user-facing response
     - `extract_cot()` - Extract reasoning traces
     - `convert_to_openai_format()` - OpenAI API compatibility

## Key Model Specifications

### GPT-OSS-120B
- **Parameters**: 116.8B total, 5.1B active per token
- **Layers**: 36
- **Experts**: 128 (top-4 selection)
- **Context**: 131,072 tokens
- **Size**: 60.8 GiB
- **Hardware**: 1x 80GB GPU minimum
- **Performance**: Near o4-mini on most benchmarks

### GPT-OSS-20B
- **Parameters**: 20.9B total, 3.6B active per token
- **Layers**: 24
- **Experts**: 32 (top-4 selection)
- **Context**: 131,072 tokens
- **Size**: 12.8 GiB
- **Hardware**: 16GB GPU minimum
- **Performance**: 6x smaller but surprisingly competitive

## Reasoning Modes

| Mode | CoT Length | Cost | Use Case |
|------|-----------|------|----------|
| **low** | <2k tokens | 1x | Simple queries, fact lookup |
| **medium** | 2-8k tokens | 3-5x | Problem-solving, coding |
| **high** | 8k-32k+ tokens | 10-20x | Competition math, research |

## Tool Capabilities

1. **Browsing**: `search()` and `open()` for web interaction
2. **Python**: Jupyter notebook code execution
3. **Developer Functions**: Custom function calling

## Usage Examples

### Accessing Model Information

```python
from astra.models.model_info import get_model_info, GPT_OSS_20B_INFO

# Get model info by identifier
model_info = get_model_info("gpt-oss-20b")
print(f"Active parameters: {model_info.architecture.active_parameters:,}")

# Or use pre-configured objects
print(f"Context length: {GPT_OSS_20B_INFO.architecture.context_length:,}")

# Access benchmarks
for benchmark in GPT_OSS_20B_INFO.benchmarks:
    print(f"{benchmark.name}: {benchmark.score_high}%")
```

### Building Harmony Format Prompts

```python
from astra.infrastructure.llm.harmony import HarmonyPromptBuilder

builder = HarmonyPromptBuilder()
builder.add_system_message(
    "You are ASTRA, a helpful AI assistant.",
    reasoning_mode="medium",
    enable_browsing=False,
    enable_python=True
)
builder.add_user_message("Calculate the fibonacci sequence up to n=10")

prompt = builder.build()
```

### Configuration in Code

```python
from astra.models.config import Settings

settings = Settings()

# Model configuration
print(f"Model: {settings.llm.model_size}")
print(f"Reasoning: {settings.llm.reasoning_mode}")
print(f"Context: {settings.llm.context_length:,} tokens")
print(f"Harmony format: {settings.llm.use_harmony_format}")
```

## Performance Highlights

### Mathematics (High Reasoning)
- **AIME 2025**: 98.7% (20b), 97.9% (120b) with tools
- **GPQA Diamond**: 71.5% (20b), 80.1% (120b)

### Coding
- **Codeforces**: 2516 Elo (20b), 2622 Elo (120b)
- **SWE-Bench**: 60.7% (20b), 62.4% (120b)

### Health
- **HealthBench**: 42.5% (20b), 57.6% (120b)

## Safety Features

- **Deliberative Alignment**: Trained to refuse harmful content
- **Instruction Hierarchy**: System > Developer > User priority
- **Jailbreak Robustness**: ~97-98% resistant
- **CBRN Filtering**: Pre-training content filtered
- **CoT Monitoring**: No direct optimization (enables monitoring)

## Best Practices

### 1. Multi-Turn Conversations
```python
from astra.infrastructure.llm.harmony import strip_cot_from_history

# Always strip CoT from history
cleaned_messages = strip_cot_from_history(conversation_messages)
```

### 2. Reasoning Mode Selection
- Use **low** for simple queries (1x cost)
- Use **medium** for most tasks (3-5x cost)
- Use **high** only for complex reasoning (10-20x cost)

### 3. Tool Usage
- Enable browsing for factuality and current info
- Enable Python for calculations and analysis
- Define functions for structured actions

### 4. Safety
- Don't show analysis channel to users directly
- Implement content moderation
- Monitor CoT for hallucinations
- Add rate limiting

## Next Steps

To complete the integration:

1. **Install Dependencies**: `poetry install`
2. **Update LLM Provider**: Enhance `llamacpp.py` with harmony support
3. **Update Documentation**: Add model info to README, ARCHITECTURE
4. **Test Integration**: Verify harmony format and reasoning modes
5. **Add Benchmarking**: Test different reasoning modes

## Files Created/Modified

### Created:
- `docs/models/gpt_oss_model_card.md` (500+ lines)
- `src/astra/models/model_info.py` (550+ lines)
- `src/astra/infrastructure/llm/harmony.py` (470+ lines)
- `docs/models/README.md` (this file)

### Modified:
- `src/astra/models/config.py` - Enhanced LLMConfig
- `config/default.yaml` - Added complete model specifications
- `.env.example` - Added GPT-OSS environment variables

## References

- **Official Model Card**: OpenAI, August 5, 2025
- **License**: Apache 2.0
- **Tokenizer**: o200k_harmony (TikToken library)
- **Context Length**: 131,072 tokens (YaRN extension)
- **Knowledge Cutoff**: June 2024

---

All GPT-OSS model information is now integrated as persistent system intelligence in ASTRA!
