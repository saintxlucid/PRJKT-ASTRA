# GPT-OSS Model Card Reference

This document contains comprehensive specifications for the GPT-OSS-120B and GPT-OSS-20B models used in ASTRA.

## Overview

**Models**: gpt-oss-120b and gpt-oss-20b  
**License**: Apache 2.0  
**Release Date**: August 5, 2025  
**Developer**: OpenAI  
**Knowledge Cutoff**: June 2024

Two open-weight reasoning models designed for agentic workflows with strong instruction following, tool use (web search, Python execution), and reasoning capabilities with adjustable effort levels.

## Model Specifications

### GPT-OSS-120B

- **Total Parameters**: 116.8B (referred to as "120b" for simplicity)
- **Active Parameters**: 5.1B per token per forward pass
- **Architecture**: MoE (Mixture-of-Experts) transformer
- **Layers**: 36
- **Checkpoint Size**: 60.8 GiB
- **Quantization**: MXFP4 (4.25 bits per parameter for MoE weights)

### GPT-OSS-20B

- **Total Parameters**: 20.9B (referred to as "20b" for simplicity)
- **Active Parameters**: 3.6B per token per forward pass
- **Architecture**: MoE transformer
- **Layers**: 24
- **Checkpoint Size**: 12.8 GiB
- **Quantization**: MXFP4 (4.25 bits per parameter for MoE weights)

### Parameter Breakdown

| Component | 120b | 20b |
|-----------|------|-----|
| MLP | 114.71B | 19.12B |
| Attention | 0.96B | 0.64B |
| Embed + Unembed | 1.16B | 1.16B |
| **Active Parameters** | **5.13B** | **3.61B** |
| **Total Parameters** | **116.83B** | **20.91B** |

## Architecture Details

### Core Architecture

- **Residual Stream Dimension**: 2880
- **Normalization**: Root Mean Square (RMS) normalization before each attention and MoE block
- **Layer Placement**: Pre-LN (similar to GPT-2)

### Mixture-of-Experts (MoE)

- **Experts**: 128 (120b) / 32 (20b)
- **Top-K Selection**: Top-4 experts per token
- **Router**: Standard linear projection mapping activations to expert scores
- **Activation Function**: Gated SwiGLU (unconventional implementation with clamping and residual connection)
- **Quantization**: MXFP4 for 90%+ of parameters (MoE weights)

### Attention Mechanism

- **Pattern**: Alternating banded window (128 tokens) and fully dense
- **Query Heads**: 64 heads of dimension 64
- **Grouped Query Attention (GQA)**: 8 key-value heads
- **Position Embeddings**: Rotary Position Embeddings (RoPE)
- **Context Length**: 131,072 tokens (dense layers extended with YaRN)
- **Attention Bias**: Learned bias in softmax denominator (off-by-one attention/attention sinks)

### Tokenizer

- **Name**: o200k_harmony
- **Type**: Byte Pair Encoding (BPE)
- **Vocabulary Size**: 201,088 tokens
- **Base**: Extends o200k tokenizer (used in GPT-4o, o4-mini)
- **Special Tokens**: Includes harmony chat format tokens
- **Library**: Open-sourced in TikToken

## Training

### Pre-training

- **Dataset**: Text-only, trillions of tokens
- **Focus**: STEM, coding, general knowledge
- **Safety Filtering**: CBRN pre-training filters (from GPT-4o)
- **Knowledge Cutoff**: June 2024
- **Infrastructure**: NVIDIA H100 GPUs, PyTorch, Triton kernels
- **Compute**: 2.1M H100-hours (120b), ~210K H100-hours (20b)
- **Optimization**: Flash Attention algorithms

### Post-Training

- **Method**: Chain-of-Thought (CoT) Reinforcement Learning (similar to OpenAI o3)
- **Training Data**: Coding, math, science, and more
- **Capabilities Taught**:
  - Reasoning with CoT
  - Problem-solving
  - Tool use (browsing, Python, developer functions)
  - Variable reasoning effort
- **Personality**: Similar to ChatGPT due to similar RL techniques

## Harmony Chat Format

### Role Hierarchy

**Instruction Priority**: System > Developer > User > Assistant > Tool

- **System**: Highest priority instructions (model configuration, reasoning mode)
- **Developer**: Developer-specified instructions and function definitions
- **User**: End-user messages
- **Assistant**: Model responses
- **Tool**: Tool execution results

### Channels

Messages include channel indicators for visibility:

- **analysis**: Chain-of-thought tokens (internal reasoning)
- **commentary**: Function/tool calling metadata
- **final**: User-facing answers

### Format Features

- Special tokens for message boundaries
- Keyword arguments for authors/recipients
- Interleaving: CoT, function calls, responses, intermediate messages, final answers
- **Critical**: Remove reasoning traces from past turns in multi-turn conversations

### Tool Integration

Available tools:
1. **Browsing**: `search()` and `open()` functions for web interaction
2. **Python**: Stateful Jupyter notebook environment
3. **Developer Functions**: Arbitrary function schemas (API-style)

Tools specified in system prompt (e.g., "Enable browsing: yes")

## Reasoning Modes

Three reasoning levels configured via system prompt:

| Mode | Description | Use Case | CoT Length |
|------|-------------|----------|------------|
| **low** | Minimal reasoning effort | Simple, straightforward tasks | Short |
| **medium** | Balanced reasoning | Moderate complexity | Medium |
| **high** | Maximum reasoning effort | Complex problems requiring deep analysis | Long (20k+ tokens) |

**Configuration**: Insert keywords in system prompt: `"Reasoning: low"`, `"Reasoning: medium"`, `"Reasoning: high"`

**Test-Time Scaling**: Smooth log-linear accuracy improvements with higher reasoning levels

## Performance Benchmarks

### Main Capabilities (High Reasoning)

| Benchmark | Description | gpt-oss-120b | gpt-oss-20b | o3 | o4-mini |
|-----------|-------------|--------------|-------------|-----|----------|
| **AIME 2024** (with tools) | Competition Math | 96.6% | 96.0% | 98.7% | 95.2% |
| **AIME 2025** (with tools) | Competition Math | 97.9% | 98.7% | 98.4% | 99.5% |
| **GPQA Diamond** (no tools) | PhD Science Questions | 80.1% | 71.5% | 83.3% | 81.4% |
| **MMLU** | College-level Exams | 90.0% | 85.3% | 93.4% | 93.0% |
| **HLE** | Expert-Level Questions | 14.9% | 10.9% | 24.9% | 19.0% |

### Coding & Tool Use (High Reasoning)

| Benchmark | Description | gpt-oss-120b | gpt-oss-20b | o3 | o4-mini |
|-----------|-------------|--------------|-------------|-----|----------|
| **Codeforces** (with tools) | Competition Code | 2622 Elo | 2516 Elo | 2719 Elo | 2706 Elo |
| **SWE-Bench Verified** | Software Engineering | 62.4% | 60.7% | 69.1% | 68.1% |
| **τ-Bench Retail** | Function Calling | 67.8% | 54.8% | 70.4% | 65.6% |

### Health Performance (High Reasoning)

| Benchmark | gpt-oss-120b | gpt-oss-20b | o3 | GPT-4o |
|-----------|--------------|-------------|-----|--------|
| **HealthBench** | 57.6% | 42.5% | 59.8% | 32.0% |
| **HealthBench Hard** | 30.0% | 10.8% | 31.6% | 0.0% |
| **HealthBench Consensus** | 90.0% | 82.6% | 92.8% | 88.7% |

### Multilingual (MMMLU Average)

| Reasoning Level | gpt-oss-120b | gpt-oss-20b | o3 | o4-mini |
|-----------------|--------------|-------------|-----|----------|
| **Low** | 74.1% | 67.0% | 80.7% | 85.2% |
| **Medium** | 79.3% | 73.5% | - | - |
| **High** | 81.3% | 75.7% | 88.8% | - |

**Languages Tested**: Arabic, Bengali, Chinese, French, German, Hindi, Indonesian, Italian, Japanese, Korean, Portuguese, Spanish, Swahili, Yoruba (14 total)

### Full Evaluation Results

All accuracy percentages at different reasoning levels:

#### Mathematics & Science

| Benchmark | 120b-low | 120b-med | 120b-high | 20b-low | 20b-med | 20b-high |
|-----------|----------|----------|-----------|---------|---------|----------|
| AIME 2024 (no tools) | 56.3 | 80.4 | 95.8 | 42.1 | 80.0 | 92.1 |
| AIME 2024 (tools) | 75.4 | 87.9 | 96.6 | 61.2 | 86.0 | 96.0 |
| AIME 2025 (no tools) | 50.4 | 80.0 | 92.5 | 37.1 | 72.1 | 91.7 |
| AIME 2025 (tools) | 72.9 | 91.6 | 97.9 | 57.5 | 90.4 | 98.7 |
| GPQA Diamond (no tools) | 67.1 | 73.1 | 80.1 | 56.8 | 66.0 | 71.5 |
| GPQA Diamond (tools) | 68.1 | 73.5 | 80.9 | 58.0 | 67.1 | 74.2 |
| HLE (no tools) | 5.2 | 8.6 | 14.9 | 4.2 | 7.0 | 10.9 |
| HLE (tools) | 9.1 | 11.3 | 19.0 | 6.3 | 8.8 | 17.3 |
| MMLU | 85.9 | 88.0 | 90.0 | 80.4 | 84.0 | 85.3 |

#### Coding (Elo Ratings)

| Benchmark | 120b-low | 120b-med | 120b-high | 20b-low | 20b-med | 20b-high |
|-----------|----------|----------|-----------|---------|---------|----------|
| Codeforces (no tools) | 1595 | 2205 | 2463 | 1366 | 1998 | 2230 |
| Codeforces (tools) | 1653 | 2365 | 2622 | 1251 | 2064 | 2516 |
| SWE-Bench Verified | 47.9 | 52.6 | 62.4 | 37.4 | 53.2 | 60.7 |

#### Tool Use & Specialized

| Benchmark | 120b-low | 120b-med | 120b-high | 20b-low | 20b-med | 20b-high |
|-----------|----------|----------|-----------|---------|---------|----------|
| τ-Bench Retail | 49.4 | 62.0 | 67.8 | 35.0 | 47.3 | 54.8 |
| τ-Bench Airline | 42.6 | 48.6 | 49.2 | 32.0 | 42.6 | 38.0 |
| Aider Polyglot | 24.0 | 34.2 | 44.4 | 16.6 | 26.6 | 34.2 |

#### Health (Score %)

| Benchmark | 120b-low | 120b-med | 120b-high | 20b-low | 20b-med | 20b-high |
|-----------|----------|----------|-----------|---------|---------|----------|
| HealthBench | 53.0 | 55.9 | 57.6 | 40.4 | 41.8 | 42.5 |
| HealthBench Hard | 22.8 | 26.9 | 30.0 | 9.0 | 12.9 | 10.8 |
| HealthBench Consensus | 90.6 | 90.8 | 89.9 | 84.9 | 83.0 | 82.6 |

## Safety & Alignment

### Training Approach

- **Deliberative Alignment**: Teaches refusal on disallowed content
- **Instruction Hierarchy**: Follows System > Developer > User > Assistant > Tool
- **Jailbreak Robustness**: Trained to resist adversarial prompts
- **CBRN Filtering**: Pre-training data filtered for hazardous biosecurity knowledge

### Chain-of-Thought Monitoring

- **No Direct Optimization**: CoT not pressured against "bad thoughts"
- **Monitorability**: Enables developers to implement CoT monitoring
- **Warning**: CoT may contain hallucinated content; don't show directly to users
- **Research**: Supports community study of CoT monitorability

### Safety Performance

- **Disallowed Content**: On par with o4-mini (99%+ refusal rates)
- **Jailbreak Defense**: Similar to o4-mini (97-98% robust)
- **Instruction Hierarchy**: Slightly weaker than o4-mini but compensated by fine-tuning ability
- **Hallucinations**: Higher than o4-mini (smaller models = less world knowledge)
- **Fairness (BBQ)**: On par with o4-mini

### Preparedness Framework

OpenAI's Safety Advisory Group (SAG) concluded:
- **Biological/Chemical Risk**: Did not reach "High" capability (even with adversarial fine-tuning)
- **Cyber Risk**: Did not reach "High" capability (even with adversarial fine-tuning)
- **AI Self-Improvement**: Did not reach "High" capability
- **Open Model Frontier**: Does not significantly advance biosecurity capabilities beyond existing open models (Qwen 3, Kimi K2, DeepSeek R1)

## Model Selection Guide

### When to Use GPT-OSS-120B

- **Complex reasoning tasks**: Advanced math, science, research
- **High accuracy requirements**: Approaching o4-mini performance
- **Long-context scenarios**: 131k token context window
- **Sufficient resources**: 60.8 GiB model, requires 80GB GPU

### When to Use GPT-OSS-20B

- **Resource-constrained environments**: Runs on 16GB+ systems
- **Good performance/cost tradeoff**: 6x smaller, still competitive
- **Fast inference**: Fewer parameters = faster generation
- **Batch processing**: Can run multiple instances

### Reasoning Mode Selection

| Task Complexity | Recommended Mode | Expected CoT Length | Relative Cost |
|----------------|------------------|---------------------|---------------|
| Simple queries, fact lookup | **low** | <2k tokens | 1x |
| Moderate problem-solving | **medium** | 2-8k tokens | 3-5x |
| Complex analysis, competition math | **high** | 8k-32k+ tokens | 10-20x |

## Deployment Considerations

### Hardware Requirements

**gpt-oss-120b**:
- Minimum: 1x 80GB GPU (A100, H100)
- Recommended: 2x 80GB GPUs for production
- Memory: 64GB+ RAM

**gpt-oss-20b**:
- Minimum: 16GB GPU (RTX 4090, V100)
- Recommended: 24GB+ GPU for production
- Memory: 32GB+ RAM

### Inference Optimization

- **Quantization**: Already MXFP4 (4.25 bpp) - further quantization possible
- **Batch Size**: Adjust based on VRAM availability
- **Context Window**: 131k tokens maximum (use YaRN for extension)
- **Caching**: Cache frequent system/developer messages

### Multi-Turn Conversations

**Critical**: Remove reasoning traces from past assistant turns in conversation history
- Keeps context manageable
- Prevents CoT contamination
- Improves relevance

## API Compatibility

- **OpenAI Responses API**: Compatible format
- **Harmony Format**: Custom format for full capabilities
- **Streaming**: Supported with SSE (Server-Sent Events)
- **Function Calling**: Developer functions via harmony format
- **Structured Outputs**: Supported

## Known Limitations

1. **Text-Only**: No vision capabilities (multimodal limited)
2. **Hallucinations**: Higher rate than larger frontier models
3. **Knowledge Cutoff**: June 2024 (use browsing tool for current info)
4. **Instruction Hierarchy**: Slightly weaker than o4-mini
5. **Context Window**: While 131k, practical limits may be lower
6. **Fine-tuning**: Can be adversarially fine-tuned by malicious actors

## Best Practices

### System Prompt Design

```
Reasoning: {low|medium|high}
Enable browsing: {yes|no}
Enable python: {yes|no}
{Additional system instructions}
```

### Conversation Management

1. **Remove past CoT**: Strip `analysis` channel from history
2. **Keep tool results**: Maintain `Tool` messages for context
3. **Preserve structure**: Maintain role hierarchy
4. **Limit context**: Summarize old messages to stay within 131k

### Safety Integration

1. **Monitor CoT**: Implement monitoring systems for reasoning traces
2. **Filter output**: Don't show raw `analysis` channel to users
3. **Content moderation**: Add application-specific filters
4. **Rate limiting**: Prevent abuse, especially with high reasoning
5. **Logging**: Track usage for safety auditing

### Tool Use

1. **Browsing**: Enable for factuality, current events
2. **Python**: Use for calculations, data analysis, visualizations
3. **Functions**: Define clear schemas, handle errors gracefully
4. **Interleaving**: Allow model to plan and execute multi-step operations

## References

- **Model Card**: OpenAI, August 5, 2025
- **License**: Apache 2.0
- **Usage Policy**: OpenAI gpt-oss usage policy
- **TikToken Library**: https://github.com/openai/tiktoken
- **Harmony Format Guide**: See OpenAI documentation

## Changelog

### August 5, 2025
- Initial release of gpt-oss-120b and gpt-oss-20b
- Apache 2.0 license
- Open weights available
- Harmony chat format introduced
- Variable reasoning effort (low/medium/high)
- Tool use capabilities (browsing, Python, functions)

---

**Note**: This document is a reference derived from the official OpenAI GPT-OSS Model Card. For the most up-to-date information, consult OpenAI's official documentation.
