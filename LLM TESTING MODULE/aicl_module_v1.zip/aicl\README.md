# AICL - AI Interchange Chat Language

AICL is a lightweight, efficient communication protocol designed for LLM-to-LLM interactions. It provides both a human-readable JSON format (AICL-Core) and a compact ASCII format (AICL-Glyph) for token-efficient communication.

## Features

- **Token-efficient**: Compact glyph format for tight token budgets
- **Extensible**: Versioned with capability negotiation
- **Deterministic**: Easy to parse with predictable structure
- **Safe**: Supports message signing, rate limiting, and governance policies
- **Rich payload**: Supports text, embeddings, logits, and tool calls

## Message Structure

### AICL-Core (JSON Lines)
```json
{
  "v": "aicl/1.0",
  "id": "3b2f7f64-3a6b-42a4-9a3f-22f6",
  "ts": "2025-10-12T12:00:00Z",
  "from": "model://neox20b",
  "to": "model://gpt2l",
  "caps": ["text","emb","tool:math","logits:topk"],
  "act": "ask",
  "topic": "distillation",
  "ctx": {"turn": 1, "thread": "abcd"},
  "limits": {"tokens": 1024, "latency_ms": 800},
  "payload": {
    "text": {"lang":"en","fmt":"md","content":"Summarize this chunk → …"},
    "emb": null,
    "logits": null,
    "tool": null
  },
  "sig": null
}
```

### AICL-Glyph (Compact ASCII)
```
A1|id=3b2f...|f=neox20b|t=gpt2l|a=ask|tp=distill|trn=1|tk=1024|
TXT:en:md|Summarize→ …
```

## Usage

```python
from aicl import aicl

# Create a message
msg = aicl.new_msg(
    frm="model://neox20b",
    to="model://gpt2l",
    act="ask",
    payload={
        "text": {
            "lang": "en",
            "fmt": "md",
            "content": "Summarize: Large language models are powerful."
        }
    }
)

# Serialize to JSON
json_msg = aicl.aicl_core(msg)

# Convert to compact glyph format
glyph_msg = aicl.to_glyph(msg)

# Parse glyph back to dict
parsed_msg = aicl.from_glyph(glyph_msg)

# Sign and verify messages
key = b"secret_key"
signed_msg = aicl.sign(msg, key)
is_valid = aicl.verify(signed_msg, key)
```

## Message Types

- `ask`: Request information or action
- `answer`: Response to an ask
- `inform`: Share information
- `plan`: Share execution plan
- `tool_call`: Request tool execution
- `tool_result`: Return tool execution result
- `ping`/`pong`: Liveness check
- `error`: Report an error
- `ack`: Acknowledge receipt

## Payload Types

1. **Text**: `{lang, fmt, content}`
2. **Embeddings**: `{model, dtype, shape, b64}`
3. **Logits**: `{topk: [{"tok":"...", "p":0.12}, ...], "temperature":2.0}`
4. **Tools**: `{name, args}` for calls; `{name, ok, result|error}` for results

## Safety Features

- **Quota enforcement**: `limits.tokens`, `limits.latency_ms`
- **Policy headers**: Optional PII handling, jailbreak detection
- **Message signing**: HMAC or ed25519 signatures
- **Replay protection**: Refuse duplicate message IDs